questions_answers = {
    "What courses are offered?": "We offer various courses in Electronic and Telecommunication, Renewable Energy, Mechatronics, and Information Technology.",
    "How can I apply?": "You can apply online through our admission portal.",
    "Where is the campus located?": "Our campus is located in Rulindo district, Bushoki Sector.",
    "What extracurricular activities are available?": "We have clubs for music, sports, and art.",
    # Add more questions and answers here.
}
